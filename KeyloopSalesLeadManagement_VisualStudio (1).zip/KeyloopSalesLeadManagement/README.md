# Keyloop Sales Lead Management API

Backend implementation starter for **Scenario C: Sales Lead Management Tool**.

## Stack
.NET 8, ASP.NET Core Web API, C#, SQL Server, ADO.NET (`Microsoft.Data.SqlClient`), Swagger/OpenAPI, xUnit and Moq.

## Open in Visual Studio
1. Extract this ZIP.
2. Open `KeyloopSalesLeadManagement.sln` in Visual Studio 2022 with the **ASP.NET and web development** workload.
3. Ensure .NET 8 SDK and SQL Server LocalDB (or SQL Server Developer Edition) are installed.
4. Open `database/01-create-database-and-tables.sql` in SSMS and execute it. **Warning:** the script drops and recreates the two project tables.
5. Confirm `src/Keyloop.LeadManagement.Api/appsettings.json` points to your SQL Server. Default is `(localdb)\MSSQLLocalDB`; for SQL Express, use `localhost\SQLEXPRESS`.
6. Set `Keyloop.LeadManagement.Api` as startup project and press F5.
7. Open the Swagger URL displayed by Visual Studio, usually ending in `/swagger`.

## Endpoints
- `GET /api/leads` — list leads
- `GET /api/leads?status=New` — filter by status
- `GET /api/leads/{id}` — lead and activity history
- `POST /api/leads` — create lead
- `GET /api/leads/{id}/activities` — get activity history
- `POST /api/leads/{id}/activities` — log a follow-up

Example POST `/api/leads` JSON:
```json
{
  "customerName": "Ravi Kumar",
  "email": "ravi@example.com",
  "phone": "+919876543210",
  "vehicleInterest": "SUV"
}
```

Example POST `/api/leads/1/activities` JSON:
```json
{
  "activityType": "Called customer",
  "notes": "Customer asked for an on-road price quotation."
}
```

## Tests
In Visual Studio choose **Test > Run All Tests**, or run `dotnet test` from the solution folder. Unit tests mock the repository and do not need a live database. Verify database/API integration manually through Swagger and SSMS; integration tests are a recommended next step.

## AI collaboration narrative — make this accurate before submitting
I used an AI assistant to help translate the assessment requirements into a backend design, draft an initial implementation, and identify test cases. I reviewed the code, checked that SQL commands use typed parameters, inspected the relational constraints and indexes, and ran the build and tests. I refined the code based on the actual results and manual API testing. I remain responsible for understanding the implementation and explaining the design decisions.

Update this section to describe the AI tools and checks you actually used. Do not claim the tests passed until you have run them successfully.

## Assumptions / limitations
- New leads start in status `New`.
- Database-supported statuses: `New`, `Contacted`, `Qualified`, `Lost`, `Converted`.
- Activities are returned newest first; SQL Server creates UTC timestamps.
- Authentication/authorization and status-update endpoints are not included in this starter.
- Do not commit production secrets; use user secrets or environment variables outside local development.
