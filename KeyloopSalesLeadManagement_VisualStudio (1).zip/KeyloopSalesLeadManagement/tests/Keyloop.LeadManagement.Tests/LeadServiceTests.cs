using Keyloop.LeadManagement.Api.Data;
using Keyloop.LeadManagement.Api.Models;
using Keyloop.LeadManagement.Api.Services;
using Moq;
using Xunit;

namespace Keyloop.LeadManagement.Tests;
public sealed class LeadServiceTests
{
    private readonly Mock<ILeadRepository> _repo = new();
    private LeadService CreateService() => new(_repo.Object);

    [Fact]
    public async Task GetById_ReturnsRepositoryLead()
    {
        _repo.Setup(r => r.GetByIdAsync(7, It.IsAny<CancellationToken>()))
            .ReturnsAsync(new Lead { Id = 7, CustomerName = "Test Customer" });
        var result = await CreateService().GetByIdAsync(7, CancellationToken.None);
        Assert.NotNull(result);
        Assert.Equal("Test Customer", result.CustomerName);
    }

    [Fact]
    public async Task GetActivities_ReturnsNullIfLeadDoesNotExist()
    {
        _repo.Setup(r => r.ExistsAsync(99, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var result = await CreateService().GetActivitiesAsync(99, CancellationToken.None);
        Assert.Null(result);
        _repo.Verify(r => r.GetActivitiesAsync(It.IsAny<int>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task AddActivity_DoesNotSaveForMissingLead()
    {
        _repo.Setup(r => r.ExistsAsync(99, It.IsAny<CancellationToken>())).ReturnsAsync(false);
        var result = await CreateService().AddActivityAsync(99,
            new CreateActivityRequest { ActivityType = "Call", Notes = "No answer" }, CancellationToken.None);
        Assert.Null(result);
        _repo.Verify(r => r.AddActivityAsync(It.IsAny<int>(), It.IsAny<CreateActivityRequest>(), It.IsAny<CancellationToken>()), Times.Never);
    }

    [Fact]
    public async Task AddActivity_SavesWhenLeadExists()
    {
        _repo.Setup(r => r.ExistsAsync(7, It.IsAny<CancellationToken>())).ReturnsAsync(true);
        _repo.Setup(r => r.AddActivityAsync(7, It.IsAny<CreateActivityRequest>(), It.IsAny<CancellationToken>())).ReturnsAsync(15);
        var result = await CreateService().AddActivityAsync(7,
            new CreateActivityRequest { ActivityType = "Call", Notes = "Discussed test drive" }, CancellationToken.None);
        Assert.Equal(15, result);
    }
}
