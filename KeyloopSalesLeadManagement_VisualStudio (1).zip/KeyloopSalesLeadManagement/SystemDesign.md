# System Design — Keyloop Sales Lead Management API

## Scope
Backend implementation for Scenario C: list incoming leads, retrieve lead details and chronological follow-up history, and persist new activities.

## Architecture
```mermaid
flowchart TD
    Client[Swagger / HTTP client] --> Controller[LeadsController]
    Controller --> Service[ILeadService / LeadService]
    Service --> Repo[ILeadRepository / SqlLeadRepository]
    Repo --> DB[(SQL Server)]
    DB --> Leads[Leads]
    DB --> Activities[LeadActivities]
```

## Components
- **Controller:** HTTP routes, request binding, validation and HTTP response codes.
- **Service:** business logic; checks lead existence before activity operations.
- **Repository:** ADO.NET SQL access and mapping between rows and C# models.
- **SQL Server:** persistent data, foreign key, status constraint and indexes.
- **Swagger:** interactive API contract/client substitute.
- **xUnit + Moq:** isolated service unit tests.

## Data model
`Leads` has a one-to-many relationship with `LeadActivities`. The activity foreign key preserves referential integrity. Indexes support status/date filtering and activity-history retrieval.

## Data flow
HTTP request → controller → service interface/implementation → repository interface/implementation → parameterized SQL query → SQL Server → mapped response → HTTP client.

## Technology choices
.NET 8 / ASP.NET Core for REST endpoints; ADO.NET for explicit SQL Server access; SQL Server for relational persistence; Swagger for API exploration; xUnit and Moq for tests.

## Observability, reliability and security
ASP.NET Core built-in logging is enabled. Cancellation tokens are passed to database operations. SQL uses typed parameters. SQL constraints protect data integrity. Before production, add global exception handling, structured request/correlation logging, health checks, metrics/tracing, integration tests and appropriate authentication/authorization. Keep production credentials out of source control and do not log customer secrets.

## Assumptions
Leads start with status `New`; statuses are `New`, `Contacted`, `Qualified`, `Lost`, `Converted`. Activities are returned newest first. SQL Server supplies UTC timestamps. Swagger is used as the simple test client.

## GenAI collaboration
Replace this section with an honest account of the prompts and tools used, the generated code you reviewed, defects you found, and the tests you personally ran. Do not claim verification that has not happened.
