IF DB_ID(N'KeyloopLeadManagement') IS NULL CREATE DATABASE KeyloopLeadManagement;
GO
USE KeyloopLeadManagement;
GO
-- Warning: this starter script drops and recreates these project tables.
IF OBJECT_ID(N'dbo.LeadActivities', N'U') IS NOT NULL DROP TABLE dbo.LeadActivities;
IF OBJECT_ID(N'dbo.Leads', N'U') IS NOT NULL DROP TABLE dbo.Leads;
GO
CREATE TABLE dbo.Leads (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    CustomerName NVARCHAR(100) NOT NULL,
    Email NVARCHAR(254) NOT NULL,
    Phone NVARCHAR(25) NOT NULL,
    VehicleInterest NVARCHAR(100) NOT NULL,
    Status NVARCHAR(30) NOT NULL CONSTRAINT DF_Leads_Status DEFAULT N'New',
    CreatedAtUtc DATETIME2(0) NOT NULL CONSTRAINT DF_Leads_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_Leads_Status CHECK (Status IN (N'New',N'Contacted',N'Qualified',N'Lost',N'Converted'))
);
GO
CREATE TABLE dbo.LeadActivities (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    LeadId INT NOT NULL,
    ActivityType NVARCHAR(50) NOT NULL,
    Notes NVARCHAR(1000) NOT NULL,
    CreatedAtUtc DATETIME2(0) NOT NULL CONSTRAINT DF_LeadActivities_CreatedAtUtc DEFAULT SYSUTCDATETIME(),
    CONSTRAINT FK_LeadActivities_Leads FOREIGN KEY (LeadId) REFERENCES dbo.Leads(Id) ON DELETE CASCADE
);
GO
CREATE INDEX IX_Leads_Status_CreatedAtUtc ON dbo.Leads(Status, CreatedAtUtc DESC);
CREATE INDEX IX_LeadActivities_LeadId_CreatedAtUtc ON dbo.LeadActivities(LeadId, CreatedAtUtc DESC);
GO
INSERT INTO dbo.Leads(CustomerName,Email,Phone,VehicleInterest,Status) VALUES
(N'Arjun Rao',N'arjun@example.com',N'+919876543210',N'SUV',N'New'),
(N'Meera Shah',N'meera@example.com',N'+919876543211',N'Sedan',N'Contacted');
INSERT INTO dbo.LeadActivities(LeadId,ActivityType,Notes) VALUES
(1,N'Website enquiry',N'Customer requested SUV pricing.');
GO
