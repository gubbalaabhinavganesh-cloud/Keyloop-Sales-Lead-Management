using System.Data;
using Keyloop.LeadManagement.Api.Models;
using Microsoft.Data.SqlClient;

namespace Keyloop.LeadManagement.Api.Data;

public sealed class SqlLeadRepository(IConfiguration configuration) : ILeadRepository
{
    private readonly string _cs = configuration.GetConnectionString("DefaultConnection")
        ?? throw new InvalidOperationException("Missing DefaultConnection.");
    private SqlConnection Connection() => new(_cs);

    public async Task<IReadOnlyList<Lead>> GetAllAsync(string? status, CancellationToken ct)
    {
        const string sql = @"SELECT Id,CustomerName,Email,Phone,VehicleInterest,Status,CreatedAtUtc
            FROM dbo.Leads WHERE (@Status IS NULL OR Status=@Status) ORDER BY CreatedAtUtc DESC, Id DESC;";
        var result = new List<Lead>();
        await using var cn = Connection();
        await using var cmd = new SqlCommand(sql, cn);
        cmd.Parameters.Add("@Status", SqlDbType.NVarChar, 30).Value =
            string.IsNullOrWhiteSpace(status) ? DBNull.Value : status.Trim();
        await cn.OpenAsync(ct);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct)) result.Add(MapLead(reader));
        return result;
    }

    public async Task<Lead?> GetByIdAsync(int id, CancellationToken ct)
    {
        const string sql = @"SELECT Id,CustomerName,Email,Phone,VehicleInterest,Status,CreatedAtUtc
            FROM dbo.Leads WHERE Id=@Id;";
        await using var cn = Connection();
        await using var cmd = new SqlCommand(sql, cn);
        cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
        await cn.OpenAsync(ct);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        if (!await reader.ReadAsync(ct)) return null;
        var lead = MapLead(reader);
        await reader.CloseAsync();
        lead.Activities = (await GetActivitiesAsync(id, ct)).ToList();
        return lead;
    }

    public async Task<int> CreateAsync(CreateLeadRequest request, CancellationToken ct)
    {
        const string sql = @"INSERT INTO dbo.Leads(CustomerName,Email,Phone,VehicleInterest,Status)
            OUTPUT INSERTED.Id VALUES(@Name,@Email,@Phone,@Vehicle,N'New');";
        await using var cn = Connection();
        await using var cmd = new SqlCommand(sql, cn);
        cmd.Parameters.Add("@Name", SqlDbType.NVarChar, 100).Value = request.CustomerName.Trim();
        cmd.Parameters.Add("@Email", SqlDbType.NVarChar, 254).Value = request.Email.Trim();
        cmd.Parameters.Add("@Phone", SqlDbType.NVarChar, 25).Value = request.Phone.Trim();
        cmd.Parameters.Add("@Vehicle", SqlDbType.NVarChar, 100).Value = request.VehicleInterest.Trim();
        await cn.OpenAsync(ct);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));
    }

    public async Task<IReadOnlyList<LeadActivity>> GetActivitiesAsync(int leadId, CancellationToken ct)
    {
        const string sql = @"SELECT Id,LeadId,ActivityType,Notes,CreatedAtUtc FROM dbo.LeadActivities
            WHERE LeadId=@LeadId ORDER BY CreatedAtUtc DESC, Id DESC;";
        var result = new List<LeadActivity>();
        await using var cn = Connection();
        await using var cmd = new SqlCommand(sql, cn);
        cmd.Parameters.Add("@LeadId", SqlDbType.Int).Value = leadId;
        await cn.OpenAsync(ct);
        await using var reader = await cmd.ExecuteReaderAsync(ct);
        while (await reader.ReadAsync(ct))
            result.Add(new LeadActivity { Id=reader.GetInt32(0), LeadId=reader.GetInt32(1),
                ActivityType=reader.GetString(2), Notes=reader.GetString(3), CreatedAtUtc=reader.GetDateTime(4) });
        return result;
    }

    public async Task<int> AddActivityAsync(int leadId, CreateActivityRequest request, CancellationToken ct)
    {
        const string sql = @"INSERT INTO dbo.LeadActivities(LeadId,ActivityType,Notes)
            OUTPUT INSERTED.Id VALUES(@LeadId,@Type,@Notes);";
        await using var cn = Connection();
        await using var cmd = new SqlCommand(sql, cn);
        cmd.Parameters.Add("@LeadId", SqlDbType.Int).Value = leadId;
        cmd.Parameters.Add("@Type", SqlDbType.NVarChar, 50).Value = request.ActivityType.Trim();
        cmd.Parameters.Add("@Notes", SqlDbType.NVarChar, 1000).Value = request.Notes.Trim();
        await cn.OpenAsync(ct);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct));
    }

    public async Task<bool> ExistsAsync(int leadId, CancellationToken ct)
    {
        await using var cn = Connection();
        await using var cmd = new SqlCommand(
            "SELECT CASE WHEN EXISTS(SELECT 1 FROM dbo.Leads WHERE Id=@Id) THEN 1 ELSE 0 END;", cn);
        cmd.Parameters.Add("@Id", SqlDbType.Int).Value = leadId;
        await cn.OpenAsync(ct);
        return Convert.ToInt32(await cmd.ExecuteScalarAsync(ct)) == 1;
    }

    private static Lead MapLead(SqlDataReader r) => new()
    {
        Id=r.GetInt32(0), CustomerName=r.GetString(1), Email=r.GetString(2), Phone=r.GetString(3),
        VehicleInterest=r.GetString(4), Status=r.GetString(5), CreatedAtUtc=r.GetDateTime(6)
    };
}
