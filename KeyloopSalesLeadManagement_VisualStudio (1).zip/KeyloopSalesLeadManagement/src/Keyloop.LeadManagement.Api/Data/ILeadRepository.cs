using Keyloop.LeadManagement.Api.Models;
namespace Keyloop.LeadManagement.Api.Data;
public interface ILeadRepository
{
    Task<IReadOnlyList<Lead>> GetAllAsync(string? status, CancellationToken ct);
    Task<Lead?> GetByIdAsync(int id, CancellationToken ct);
    Task<int> CreateAsync(CreateLeadRequest request, CancellationToken ct);
    Task<IReadOnlyList<LeadActivity>> GetActivitiesAsync(int leadId, CancellationToken ct);
    Task<int> AddActivityAsync(int leadId, CreateActivityRequest request, CancellationToken ct);
    Task<bool> ExistsAsync(int leadId, CancellationToken ct);
}
