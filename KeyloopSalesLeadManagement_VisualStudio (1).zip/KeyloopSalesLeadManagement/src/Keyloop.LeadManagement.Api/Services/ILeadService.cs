using Keyloop.LeadManagement.Api.Models;
namespace Keyloop.LeadManagement.Api.Services;
public interface ILeadService
{
    Task<IReadOnlyList<Lead>> GetAllAsync(string? status, CancellationToken ct);
    Task<Lead?> GetByIdAsync(int id, CancellationToken ct);
    Task<int> CreateAsync(CreateLeadRequest request, CancellationToken ct);
    Task<IReadOnlyList<LeadActivity>?> GetActivitiesAsync(int id, CancellationToken ct);
    Task<int?> AddActivityAsync(int id, CreateActivityRequest request, CancellationToken ct);
}
