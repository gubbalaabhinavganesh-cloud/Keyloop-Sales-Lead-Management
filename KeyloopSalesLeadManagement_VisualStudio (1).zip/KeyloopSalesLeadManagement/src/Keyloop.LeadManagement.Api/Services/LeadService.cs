using Keyloop.LeadManagement.Api.Data;
using Keyloop.LeadManagement.Api.Models;
namespace Keyloop.LeadManagement.Api.Services;
public sealed class LeadService(ILeadRepository repository) : ILeadService
{
    public Task<IReadOnlyList<Lead>> GetAllAsync(string? status, CancellationToken ct) => repository.GetAllAsync(status, ct);
    public Task<Lead?> GetByIdAsync(int id, CancellationToken ct) => repository.GetByIdAsync(id, ct);
    public Task<int> CreateAsync(CreateLeadRequest request, CancellationToken ct) => repository.CreateAsync(request, ct);
    public async Task<IReadOnlyList<LeadActivity>?> GetActivitiesAsync(int id, CancellationToken ct)
    {
        if (!await repository.ExistsAsync(id, ct)) return null;
        return await repository.GetActivitiesAsync(id, ct);
    }
    public async Task<int?> AddActivityAsync(int id, CreateActivityRequest request, CancellationToken ct)
    {
        if (!await repository.ExistsAsync(id, ct)) return null;
        return await repository.AddActivityAsync(id, request, ct);
    }
}
