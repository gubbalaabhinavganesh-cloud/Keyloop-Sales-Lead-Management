using System.ComponentModel.DataAnnotations;
namespace Keyloop.LeadManagement.Api.Models;
public sealed class CreateActivityRequest
{
    [Required, StringLength(50, MinimumLength = 2)] public string ActivityType { get; init; } = "";
    [Required, StringLength(1000, MinimumLength = 2)] public string Notes { get; init; } = "";
}
