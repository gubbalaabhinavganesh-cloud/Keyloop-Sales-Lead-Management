using System.ComponentModel.DataAnnotations;
namespace Keyloop.LeadManagement.Api.Models;
public sealed class CreateLeadRequest
{
    [Required, StringLength(100, MinimumLength = 2)] public string CustomerName { get; init; } = "";
    [Required, EmailAddress, StringLength(254)] public string Email { get; init; } = "";
    [Required, Phone, StringLength(25, MinimumLength = 7)] public string Phone { get; init; } = "";
    [Required, StringLength(100)] public string VehicleInterest { get; init; } = "";
}
