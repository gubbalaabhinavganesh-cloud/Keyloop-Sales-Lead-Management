namespace Keyloop.LeadManagement.Api.Models;
public sealed class Lead
{
    public int Id { get; set; }
    public string CustomerName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Phone { get; set; } = "";
    public string VehicleInterest { get; set; } = "";
    public string Status { get; set; } = "New";
    public DateTime CreatedAtUtc { get; set; }
    public List<LeadActivity> Activities { get; set; } = [];
}
