namespace Keyloop.LeadManagement.Api.Models;
public sealed class LeadActivity
{
    public int Id { get; set; }
    public int LeadId { get; set; }
    public string ActivityType { get; set; } = "";
    public string Notes { get; set; } = "";
    public DateTime CreatedAtUtc { get; set; }
}
