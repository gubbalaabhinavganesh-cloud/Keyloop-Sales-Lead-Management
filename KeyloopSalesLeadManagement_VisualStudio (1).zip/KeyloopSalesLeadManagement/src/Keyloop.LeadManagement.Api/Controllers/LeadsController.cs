using Keyloop.LeadManagement.Api.Models;
using Keyloop.LeadManagement.Api.Services;
using Microsoft.AspNetCore.Mvc;
namespace Keyloop.LeadManagement.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public sealed class LeadsController(ILeadService service) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> GetAll([FromQuery] string? status, CancellationToken ct) =>
        Ok(await service.GetAllAsync(status, ct));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id, CancellationToken ct)
    {
        if (id <= 0) return BadRequest(new { message = "Lead ID must be greater than zero." });
        var lead = await service.GetByIdAsync(id, ct);
        return lead is null ? NotFound() : Ok(lead);
    }

    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateLeadRequest request, CancellationToken ct)
    {
        var id = await service.CreateAsync(request, ct);
        return CreatedAtAction(nameof(GetById), new { id }, new { id, message = "Lead created successfully." });
    }

    [HttpGet("{id:int}/activities")]
    public async Task<IActionResult> GetActivities(int id, CancellationToken ct)
    {
        if (id <= 0) return BadRequest(new { message = "Lead ID must be greater than zero." });
        var activities = await service.GetActivitiesAsync(id, ct);
        return activities is null ? NotFound() : Ok(activities);
    }

    [HttpPost("{id:int}/activities")]
    public async Task<IActionResult> AddActivity(int id, [FromBody] CreateActivityRequest request, CancellationToken ct)
    {
        if (id <= 0) return BadRequest(new { message = "Lead ID must be greater than zero." });
        var activityId = await service.AddActivityAsync(id, request, ct);
        if (activityId is null) return NotFound(new { message = $"Lead {id} was not found." });
        return StatusCode(StatusCodes.Status201Created, new { id = activityId, leadId = id, message = "Activity logged." });
    }
}
