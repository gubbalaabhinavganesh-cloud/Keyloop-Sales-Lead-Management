using Keyloop.LeadManagement.Api.Data;
using Keyloop.LeadManagement.Api.Services;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddScoped<ILeadRepository, SqlLeadRepository>();
builder.Services.AddScoped<ILeadService, LeadService>();

var app = builder.Build();
if (app.Environment.IsDevelopment()) { app.UseSwagger(); app.UseSwaggerUI(); }
app.UseHttpsRedirection();
app.MapControllers();
app.Run();
public partial class Program { }
